<?php
declare(strict_types=1);
session_start();

const ADMIN_PASSWORD_SHA256 = 'fdfd6b0954c11e79c0ebe8ec6478cbd68b58ded16cd96efa23d63eb0cafe168a';
const DATA_FILE = __DIR__ . '/data/stats.json';

function stats(): array {
    $d = json_decode(@file_get_contents(DATA_FILE) ?: '', true);
    return [
        'views' => max(0, (int)($d['views'] ?? 0)),
        'unique' => max(0, (int)($d['unique'] ?? 0))
    ];
}
function save_stats(array $s): void {
    $fp = fopen(DATA_FILE, 'c+');
    if (!$fp) return;
    if (flock($fp, LOCK_EX)) {
        ftruncate($fp, 0); rewind($fp);
        fwrite($fp, json_encode($s));
        fflush($fp); flock($fp, LOCK_UN);
    }
    fclose($fp);
}
function esc(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
$isAdmin = ($path === 'admin' || isset($_GET['admin']));

if (!$isAdmin) {
    $s = stats();
    $s['views']++;
    if (empty($_COOKIE['letter_seen'])) {
        $s['unique']++;
        setcookie('letter_seen', '1', [
            'expires' => time() + 86400, 'path' => '/',
            'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
            'httponly' => true, 'samesite' => 'Lax'
        ]);
    }
    save_stats($s);
}

if ($isAdmin) {
    $error = '';
    if (isset($_POST['password'])) {
        $candidate = hash('sha256', (string)$_POST['password']);
        if (hash_equals(ADMIN_PASSWORD_SHA256, $candidate)) {
            session_regenerate_id(true);
            $_SESSION['letter_admin'] = true;
            header('Location: /admin'); exit;
        }
        $error = 'رمز عبور اشتباه است.';
    }
    if (isset($_POST['logout'])) {
        unset($_SESSION['letter_admin']);
        session_regenerate_id(true);
        header('Location: /admin'); exit;
    }
    $loggedIn = !empty($_SESSION['letter_admin']);
    $s = stats();
    ?>
    <!doctype html><html lang="fa" dir="rtl"><head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>پنل مدیریت نامه</title>
    <style>
    *{box-sizing:border-box}body{margin:0;min-height:100vh;padding:22px;display:grid;place-items:center;background:radial-gradient(circle at top,#263650,#0b1020 68%);font-family:Tahoma,Arial;color:#f4f6fb}
    .panel{width:min(100%,620px);padding:30px;border-radius:24px;background:#111b2ddd;border:1px solid #ffffff20;box-shadow:0 25px 70px #0008}
    h1{font-size:24px;margin:0 0 9px}.muted{color:#aebbd0;font-size:13px;line-height:2}
    input{width:100%;padding:15px;margin:15px 0;border-radius:12px;border:1px solid #40506a;background:#0b1424;color:white;font-size:16px}
    button{padding:13px 20px;border:0;border-radius:12px;background:#d8b66f;color:#171717;font-weight:bold;font-size:14px;cursor:pointer}
    .error{color:#ff9d9d}.stats{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin:24px 0}
    .stat{padding:22px;border-radius:17px;background:linear-gradient(145deg,#23334e,#121d31);border:1px solid #ffffff12}
    .label{font-size:13px;color:#b9c5d8}.num{font-size:34px;font-weight:bold;color:#e7c77f;margin-top:13px;direction:ltr;text-align:right}
    .actions{display:flex;align-items:center;gap:14px;flex-wrap:wrap}a{color:#e7c77f;text-decoration:none}
    @media(max-width:480px){.panel{padding:22px}.stats{grid-template-columns:1fr}}
    </style></head><body><main class="panel">
    <?php if (!$loggedIn): ?>
      <h1>ورود به پنل مدیریت</h1><p class="muted">برای مشاهده آمار بازدید نامه، رمز عبور را وارد کنید.</p>
      <?php if ($error): ?><p class="error"><?= esc($error) ?></p><?php endif; ?>
      <form method="post"><input type="password" name="password" placeholder="رمز عبور مدیریت" required autofocus><button>ورود به پنل</button></form>
    <?php else: ?>
      <h1>داشبورد آمار نامه</h1><p class="muted">آمار ثبت‌شده برای صفحه اصلی</p>
      <section class="stats">
        <div class="stat"><div class="label">مجموع بازدیدها</div><div class="num"><?= number_format($s['views']) ?></div></div>
        <div class="stat"><div class="label">بازدیدکننده یکتا (تقریبی، ۲۴ ساعته)</div><div class="num"><?= number_format($s['unique']) ?></div></div>
      </section>
      <p class="muted">بازدیدهای پنل مدیریت شمرده نمی‌شوند. شمارنده یکتا با کوکی مرورگر کار می‌کند؛ پاک‌کردن کوکی یا استفاده از مرورگر دیگر ممکن است یک نفر را دوباره حساب کند.</p>
      <div class="actions"><form method="post"><button name="logout" value="1">خروج</button></form><a href="/">مشاهده نامه</a></div>
    <?php endif; ?>
    </main></body></html><?php
    exit;
}
?>
<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#101827"><title>مشاهده نامه</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;padding:28px 16px;background:linear-gradient(135deg,#0b1220,#1b2638);font-family:Tahoma,Arial;color:#f5f6fa}
.wrap{width:min(100%,920px);margin:auto}header{text-align:center;margin:8px 0 24px}
.eyebrow{font-size:11px;letter-spacing:2px;color:#d7b56d}h1{font-size:clamp(22px,4vw,30px);margin:10px 0}
.sub{font-size:13px;line-height:2;color:#aeb9ca}.paper{padding:10px;background:#fff;border-radius:18px;box-shadow:0 22px 65px #0008}
.paper img{display:block;width:100%;height:auto;border-radius:8px}footer{text-align:center;color:#8794a9;font-size:12px;margin:20px 0}
</style></head><body><main class="wrap">
<header><div class="eyebrow">DOCUMENT VIEWER</div><h1>تصویر نامه</h1><div class="sub">برای مشاهده جزئیات، تصویر را بزرگ‌نمایی کنید.</div></header>
<section class="paper"><img src="/assets/letter.jpg" alt="تصویر نامه"></section>
<footer>نمایش سند • مناسب موبایل و رایانه</footer>
</main></body></html>
